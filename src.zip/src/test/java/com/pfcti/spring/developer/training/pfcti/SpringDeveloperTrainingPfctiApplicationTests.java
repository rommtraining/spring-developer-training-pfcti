package com.pfcti.spring.developer.training.pfcti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDeveloperTrainingPfctiApplicationTests {

	@Test
	void contextLoads() {
	}

}
