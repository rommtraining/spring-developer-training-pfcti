package com.pfcti.spring.developer.training.pfcti.dto.enums;

public enum ClienteQueryType {
    CEDULA,
    NOMBRE
}
