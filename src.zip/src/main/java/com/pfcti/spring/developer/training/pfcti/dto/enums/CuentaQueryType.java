package com.pfcti.spring.developer.training.pfcti.dto.enums;

public enum CuentaQueryType {
    NUMERO,
    TIPO,
    ESTADO,
    CLIENTE
}
